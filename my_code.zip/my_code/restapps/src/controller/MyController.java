package controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import model.RestResponse;
import model.Track;
import services.Myservice;

@Path("/track")
public class MyController {  //rest controller,create resources,URI

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Track> getAllTracks()
	{
		System.out.println("hello");
		List<Track> tlist=new  Myservice().getAllTracks();
		return tlist;
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/get/{title}") //--/track/get/title
	public Track getTrack(@PathParam("title") String title)
	{
		Track track=new Myservice().getTrack(title);
		return track;
	}
	
	
	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse addTrack(Track track) 
	{
		boolean flag=new Myservice().addTrack(track);
		RestResponse restResponse=new RestResponse();
		if(flag)
		{
			restResponse.setCode(200);
			restResponse.setMessage("succesfully added");
		}
		else
		{
			restResponse.setCode(-1);
			restResponse.setMessage("not added");
		}
		return restResponse;
	}
	
	@DELETE
	@Path("/delete/{title}")
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse deleteTrack(@PathParam("title") String title) 
	{
		RestResponse restResponse=new RestResponse();
		boolean flag=new Myservice().deleteTrack(title);
		if(flag)
		{
			restResponse.setCode(200);
			restResponse.setMessage("succesfully removed");
		}
		else
		{
			restResponse.setCode(-1);
			restResponse.setMessage("not removed");
		}
		return restResponse;
	}
	
	@PUT
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse updateTrack(Track track) 
	{
		RestResponse restResponse=new RestResponse();
		boolean flag=new Myservice().updateTrack(track);
		if(flag)
		{
			restResponse.setCode(200);
			restResponse.setMessage("succesfully updated");
		}
		else
		{
			restResponse.setCode(-1);
			restResponse.setMessage("not updated");
		}
		return restResponse;
	}
}
