package controller;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Users;
import service.UsersDao;

/**
 * Servlet implementation class UserReg
 */
public class UserReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserReg() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cid=request.getParameter("cid");
		String name=request.getParameter("name");
		String password= request.getParameter("password");
		String qualification=request.getParameter("qualification");
		String state=request.getParameter("state");
		String enddate=request.getParameter("enddate");
		String party=request.getParameter("party");
		
		Users users=new Users(cid, name,password, qualification, state, enddate, party);
		boolean flag = new UsersDao().registerUser(users);
	
		if(flag)
		{
			response.sendRedirect("Login.html");
		}
		else
		{
			response.sendRedirect("UserReg.html");
		}
		
		
	}

}