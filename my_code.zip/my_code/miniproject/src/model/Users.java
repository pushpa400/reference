package model;

public class Users {
	
private String cid;
private String name;
private String password;
private String qualification;
private String state;
private String enddate;
private String party;
public Users(String cid, String name, String password, String qualification, String state, String enddate,
		String party) {
	super();
	this.cid = cid;
	this.name = name;
	this.password = password;
	this.qualification = qualification;
	this.state = state;
	this.enddate = enddate;
	this.party = party;
}
public Users() {
	super();
}
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public void setPassword(String password) {
	this.password = password;
}

public String getPassword() {
	return password;
}

public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getEnddate() {
	return enddate;
}
public void setEnddate(String enddate) {
	this.enddate = enddate;
}
public String getParty() {
	return party;
}
public void setParty(String party) {
	this.party = party;
}



}
