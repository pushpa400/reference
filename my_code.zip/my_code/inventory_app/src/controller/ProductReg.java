package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Product;
import services.ProductDao;
import services.UsersDao;


public class ProductReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ProductReg() {
        super();
      
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pid=request.getParameter("pid");
		String pname=request.getParameter("pname");
		int unitprice=Integer.parseInt(request.getParameter("unitprice"));
		int stock=Integer.parseInt(request.getParameter("stock"));
		String category=request.getParameter("category");
		Product product=new Product(pid, pname, unitprice, stock, category);
		boolean flag = new ProductDao().registerProduct(product);
		
		if(flag)
		{
			RequestDispatcher rd=request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg","product added succesffuly");
			rd.forward(request, response);
//			response.sendRedirect("UserHome.jsp");
//			System.out.println("added");
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg","sorry product not added succesffuly");
			rd.forward(request, response);
//			response.sendRedirect("UserHome.jsp");
//			System.out.println("failed to add");
		}
		
	}

}
