package inherit1;

public interface Interface2 {
public void disp(int a);

}
