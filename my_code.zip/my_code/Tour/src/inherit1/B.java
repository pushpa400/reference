package inherit1;

public class B extends A {

	public  B(){
		System.out.println("I am B");
	}
}
