package inherit1;

public class Myclass implements Interface1,Interface2 {

	@Override
	public void disp(int a) {
		System.out.println(a+data);
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("My output");
	}
	public static void main(String []args)
	{
		Myclass myclass=new Myclass();
		myclass.show();
		myclass.disp(120);
	}

}
