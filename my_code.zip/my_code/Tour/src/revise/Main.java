package revise;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	Savings s = new Savings("A101","xyz",7800);
	System.out.println(s.getBalance());
	s.deposit(1000);
	System.out.println(s.getBalance());
	s.withdraw(8000);
	System.out.println(s.getBalance());
	Current c= new Current("A102","ABC",12222);
	System.out.println(c.getBalance());
	c.deposit(1000);
	System.out.println(c.getBalance());
	c.withdraw(10000);
	System.out.println(c.getBalance());
	
	}
}
