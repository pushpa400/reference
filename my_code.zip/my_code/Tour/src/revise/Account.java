package revise;

public class Account {
	
	private String acno;
	private String name;
	private int balance;
	
	public Account()
	{
		super();
	}
	Account(String acno,String name,int balance){
		this.acno=acno;
		this.name=name;
		this.balance=balance;
		//this.amount=amount;
	}
	
	public String getAcno() {
		return acno;
	}

	public void setAcno(String acno) {
		this.acno = acno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public int deposit(int amount)
	{
		
		return balance+=amount;
	}
	public void  withdraw(int amount)
	{
		
		
	}
	

}
