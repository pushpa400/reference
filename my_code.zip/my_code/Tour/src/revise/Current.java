package revise;

public class Current extends Account {

	public Current() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Current(String acno, String name, int balance) {
		super(acno, name, balance);
		
	} 
	public void withdraw(int amount)
	{
		try{
			
			if(getBalance()-amount>=5000)
				setBalance(getBalance()-amount);
			else
				throw new Exception("insufficient balance");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}
