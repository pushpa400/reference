package revise;

public class Savings extends Account {

	public Savings()
	{
		super();
	}
	public Savings(String acno, String name, int balance) {
		super(acno, name, balance);
		
	} 
	public void withdraw(int amount)
	{
		try{
			
			if(getBalance()-amount>=1000)
				setBalance(getBalance()-amount);
			else
				throw new Exception("insufficient balance");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}
