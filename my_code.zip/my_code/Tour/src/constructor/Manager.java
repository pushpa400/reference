package constructor;

public class Manager extends Emp {
private int salary;
public Manager()
{
	super();
	salary=100;
}
public Manager(String name,int age,int salary)
{
	super(name,age);
	this.salary=salary;
}
public void show()
{
	super.show();
	System.out.println(salary);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m1=new Manager();m1.show();
		Manager m2=new Manager("Earn",75312,656);m2.show();
	}

}
