package constructor;

public class Emp {
private String name;
private int age;
public Emp()
{
	this("unknown",-1);
}
public Emp(String name,int age)
{
	this.name=name;
	this.age=age;
}
public void show()
{
	System.out.println(name + ""+age);
}
public static void main(String[] args)
{
	
	Emp e1=new Emp();
	e1.show();
	Emp e2=new Emp("Ram",12);
	e2.show();
}
}
