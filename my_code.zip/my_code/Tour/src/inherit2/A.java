package inherit2;

public class A {
	public void show(){
		System.out.println("I am A");
	}

}
