package inherit2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*A objc  = new B();
		objc.show();*/
		
		/*A objc;
		objc=new B();
		objc.show();
		System.out.println("--------------");
		objc=new A();
		objc.show();*/
		
		A objA =new A();
		B objB=new B();
		A objx=objB;
		objx.show();
		//B objx=(B)objA;
	}

}
