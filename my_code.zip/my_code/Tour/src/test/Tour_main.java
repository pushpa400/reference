package test;

import tourist.Tour;


public class Tour_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tour obj=new Tour();
		System.out.println(obj.getTour_id()+""+obj.getPlace());
		obj.setTour_id(123);
		obj.setPlace("mumbai");
System.out.println(obj.getTour_id()+""+obj.getPlace());
}

}
