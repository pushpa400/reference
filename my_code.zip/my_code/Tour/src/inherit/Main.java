package inherit;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A objA  = new A();
		objA.show();
		System.out.println("--------------");
		B objB = new B();
		objB.show();
		objB.display();
	}

}
