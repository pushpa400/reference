package jdbcproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertTest {

	public static void main(String[] args) throws SQLException {
		Connection connection=null;
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter student id");
			int id=Integer.parseInt(sc.nextLine());
			System.out.println("enter student name");
			String name=sc.nextLine();
			System.out.println("enter student total");
			int total=Integer.parseInt(sc.nextLine());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			//Statement smt=connection.createStatement();
			//smt.executeUpdate("insert into students values(101,'ram',234)");
			PreparedStatement pst=connection.prepareStatement("insert into students values(?,?,?)");
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setInt(3, total);
			//pst.executeUpdate();or
			int r=pst.executeUpdate();
			System.out.println("record added"+r);
			
		}
	catch (ClassNotFoundException e) 
		{
		System.out.println(e);
		}
		finally
		{
			connection.close();
		}
	}

}
