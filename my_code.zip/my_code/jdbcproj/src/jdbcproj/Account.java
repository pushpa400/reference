package jdbcproj;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter the from account number");
			int acno=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the to account number");
			int acno_t=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the amount to transfer");
			int amount=Integer.parseInt(sc.nextLine());
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			connection.setAutoCommit(false);
			PreparedStatement pst1=connection.prepareStatement(
					"UPDATE account  SET balance=balance-? where acno=?");
			PreparedStatement pst2=connection.prepareStatement(
					"UPDATE account  SET balance=balance+? where acno=?");
			
			pst1.setInt(1, amount);
			pst1.setInt(2, acno);
			Integer a=pst1.executeUpdate();
			
			pst2.setInt(1, amount);
			pst2.setInt(2, acno_t);
			Integer b=pst2.executeUpdate();
			
			if(a==1 && b==1)
				connection.commit();
			else
				connection.rollback();
			
			
			
			
			
			connection.close();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
