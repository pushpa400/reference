package controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import model.Track;
import services.Myservice;

@Path("/track")
public class MyController {  //rest controller,create resources,URI

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Track> getAllTracks()
	{
		//System.out.println("hello");
		List<Track> tlist=new  Myservice().getAllTracks();
		return tlist;
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/get/{title}") //--/track/get/title
	public Track getTrack(@PathParam("title") String title)
	{
		Track track=new Myservice().getTrack(title);
		return track;
	}
}
