package pack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		String uid=request.getParameter("uid");//from user
		String pwd=request.getParameter("pwd");
		
		ServletConfig sc=getServletConfig();//from web.xml
		String a=sc.getInitParameter("uid");  
		String b=sc.getInitParameter("pwd");
		
		if(uid.equals(a) && pwd.equals(b))
		{
			//RequestDispatcher rd=request.getRequestDispatcher("welcome.html");
			//rd.forward(request, response);
			HttpSession session=request.getSession();//retrieve session id
			session.setAttribute("uid", uid);//bind data to session
			response.sendRedirect("welcome.jsp");
			System.out.println("success");
		}
		else
		{
			//RequestDispatcher rd=request.getRequestDispatcher("login.html");
			//rd.include(request, response);
			out.println("<html><body>");
			out.println("<h3>sorry try again </h3>");
			out.println("</html></body>");
			response.sendRedirect("login.html");
			System.out.println("fail");
		}
			
	}

}
