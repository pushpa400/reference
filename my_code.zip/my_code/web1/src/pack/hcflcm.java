package pack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class hcflcm
 */
public class hcflcm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public hcflcm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int a=Integer.parseInt(request.getParameter("t1"));
		int b=Integer.parseInt(request.getParameter("t2"));
		int ch=Integer.parseInt(request.getParameter("ch"));
		PrintWriter out =  response.getWriter();
		out.println("<html><body>");
		int gcd=1,prod=a*b;
		for(int i=1;i<=a && i<=b;i++)
		{
			if(a%i==0 && b%i==0)
				gcd=i;
		}
		if(ch==1)
		{
			out.println("<b>LCM is"+(prod/gcd)+"</b>");
		}
		else if(ch==2)
		{
			out.println("<b>HCF is"+gcd+"</b>");
		}
		out.println("</html></body>");
	     
	     
	    
	    	
	    }
		
	}


