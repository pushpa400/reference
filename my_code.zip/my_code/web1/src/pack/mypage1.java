package pack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class mypage1
 */
public class mypage1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public mypage1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//a.get user selected color
		//b.store this color as cookie
		//c.redirect to page myhome.jsp
		
		String color=request.getParameter("color");
		Cookie c=new Cookie("color",color); //done at server
		response.addCookie(c); //displayed at browser
		response.sendRedirect("mypage2.jsp");
	}



}
